#!/bin/sh
echo BUILD_USER luke

echo SCAN_TAG_DEMO ""

echo SCAN_LINK_AirBnb https://airbnb.com/

echo SCAN_VALUE_Day_of_the_week $(date +%w)
