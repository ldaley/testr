package com.myproject.producer;

public class Producer {
  
  public String getValue() {
    return "value";
  }
  
}